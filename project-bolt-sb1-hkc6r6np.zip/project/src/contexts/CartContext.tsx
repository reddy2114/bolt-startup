import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase, CartItem, Product } from '../lib/supabase';
import { useAuth } from './AuthContext';

type GuestCartItem = {
  product: Product;
  quantity: number;
};

type CartContextType = {
  cartItems: CartItem[];
  guestCartItems: GuestCartItem[];
  cartCount: number;
  cartTotal: number;
  addToCart: (product: Product, quantity?: number) => void;
  updateCartItemQuantity: (itemId: string, quantity: number) => Promise<void>;
  removeFromCart: (itemId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  syncGuestCart: () => Promise<void>;
  loading: boolean;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

const GUEST_CART_KEY = 'indian_spice_guest_cart';

export function CartProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [guestCartItems, setGuestCartItems] = useState<GuestCartItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      const savedCart = localStorage.getItem(GUEST_CART_KEY);
      if (savedCart) {
        try {
          setGuestCartItems(JSON.parse(savedCart));
        } catch (e) {
          console.error('Error loading guest cart:', e);
        }
      }
    }
  }, [user]);

  const fetchCart = async () => {
    if (!user) {
      setCartItems([]);
      return;
    }

    setLoading(true);
    const { data, error } = await supabase
      .from('cart_items')
      .select('*, products(*)')
      .eq('user_id', user.id);

    if (!error && data) {
      setCartItems(data as CartItem[]);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchCart();
  }, [user]);

  const addToCart = (product: Product, quantity: number = 1) => {
    if (!user) {
      const existingItem = guestCartItems.find(item => item.product.id === product.id);
      let updatedCart: GuestCartItem[];

      if (existingItem) {
        updatedCart = guestCartItems.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        updatedCart = [...guestCartItems, { product, quantity }];
      }

      setGuestCartItems(updatedCart);
      localStorage.setItem(GUEST_CART_KEY, JSON.stringify(updatedCart));
      return;
    }

    (async () => {
      const existingItem = cartItems.find(item => item.product_id === product.id);

      if (existingItem) {
        await updateCartItemQuantity(existingItem.id, existingItem.quantity + quantity);
      } else {
        const { error } = await supabase
          .from('cart_items')
          .insert({
            user_id: user.id,
            product_id: product.id,
            quantity,
          });

        if (error) throw error;
        await fetchCart();
      }
    })();
  };

  const updateCartItemQuantity = async (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      await removeFromCart(itemId);
      return;
    }

    const { error } = await supabase
      .from('cart_items')
      .update({ quantity, updated_at: new Date().toISOString() })
      .eq('id', itemId);

    if (error) throw error;
    await fetchCart();
  };

  const removeFromCart = async (itemId: string) => {
    if (!user) {
      const updatedCart = guestCartItems.filter(item => item.product.id !== itemId);
      setGuestCartItems(updatedCart);
      localStorage.setItem(GUEST_CART_KEY, JSON.stringify(updatedCart));
      return;
    }

    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('id', itemId);

    if (error) throw error;
    await fetchCart();
  };

  const clearCart = async () => {
    if (!user) {
      setGuestCartItems([]);
      localStorage.removeItem(GUEST_CART_KEY);
      return;
    }

    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('user_id', user.id);

    if (error) throw error;
    setCartItems([]);
  };

  const syncGuestCart = async () => {
    if (!user || guestCartItems.length === 0) return;

    for (const item of guestCartItems) {
      const existingItem = cartItems.find(ci => ci.product_id === item.product.id);

      if (existingItem) {
        await supabase
          .from('cart_items')
          .update({ quantity: existingItem.quantity + item.quantity })
          .eq('id', existingItem.id);
      } else {
        await supabase
          .from('cart_items')
          .insert({
            user_id: user.id,
            product_id: item.product.id,
            quantity: item.quantity,
          });
      }
    }

    setGuestCartItems([]);
    localStorage.removeItem(GUEST_CART_KEY);
    await fetchCart();
  };

  const cartCount = user
    ? cartItems.reduce((sum, item) => sum + item.quantity, 0)
    : guestCartItems.reduce((sum, item) => sum + item.quantity, 0);

  const cartTotal = user
    ? cartItems.reduce((sum, item) => sum + item.products.price * item.quantity, 0)
    : guestCartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        cartItems,
        guestCartItems,
        cartCount,
        cartTotal,
        addToCart,
        updateCartItemQuantity,
        removeFromCart,
        clearCart,
        syncGuestCart,
        loading,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
