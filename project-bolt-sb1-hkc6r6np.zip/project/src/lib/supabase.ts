import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Product = {
  id: string;
  category_id: string;
  name: string;
  description: string;
  price: number;
  original_price: number;
  image_url: string;
  stock: number;
  unit: string;
  rating: number;
  review_count: number;
  is_featured: boolean;
  is_available: boolean;
};

export type Category = {
  id: string;
  name: string;
  slug: string;
  description: string;
  image_url: string;
};

export type CartItem = {
  id: string;
  user_id: string;
  product_id: string;
  quantity: number;
  products: Product;
};

export type Order = {
  id: string;
  user_id: string;
  order_number: string;
  status: string;
  total_amount: number;
  shipping_address: string;
  payment_method: string;
  notes: string;
  created_at: string;
};

export type Profile = {
  id: string;
  email: string;
  full_name: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
};
