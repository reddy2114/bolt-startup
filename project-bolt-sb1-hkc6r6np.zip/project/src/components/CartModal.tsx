import { X, Plus, Minus, Trash2, ShoppingBag } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { useState } from 'react';

type CartModalProps = {
  onClose: () => void;
  onCheckout: () => void;
};

export function CartModal({ onClose, onCheckout }: CartModalProps) {
  const { user } = useAuth();
  const { cartItems, guestCartItems, cartTotal, updateCartItemQuantity, removeFromCart, loading } = useCart();
  const [updating, setUpdating] = useState<string | null>(null);

  const displayItems = user ? cartItems : guestCartItems;
  const hasItems = user ? cartItems.length > 0 : guestCartItems.length > 0;

  const handleUpdateQuantity = async (itemId: string, newQuantity: number) => {
    if (!user) return;
    setUpdating(itemId);
    try {
      await updateCartItemQuantity(itemId, newQuantity);
    } finally {
      setUpdating(null);
    }
  };

  const handleRemove = async (itemId: string) => {
    setUpdating(itemId);
    try {
      await removeFromCart(itemId);
    } finally {
      setUpdating(null);
    }
  };

  const updateGuestQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      const updatedItems = guestCartItems.filter(i => i.product.id !== productId);
      localStorage.setItem('indian_spice_guest_cart', JSON.stringify(updatedItems));
      window.location.reload();
    } else {
      const updatedItems = guestCartItems.map(i =>
        i.product.id === productId
          ? { ...i, quantity: newQuantity }
          : i
      );
      localStorage.setItem('indian_spice_guest_cart', JSON.stringify(updatedItems));
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-900">Shopping Cart</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-gray-300 border-t-orange-600"></div>
            </div>
          ) : !hasItems ? (
            <div className="text-center py-12">
              <ShoppingBag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 text-lg">Your cart is empty</p>
              <p className="text-gray-500 text-sm mt-2">Add some delicious items to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              {user ? cartItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center space-x-4 bg-gray-50 rounded-lg p-4"
                >
                  <img
                    src={item.products.image_url}
                    alt={item.products.name}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate">
                      {item.products.name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      ₹{item.products.price} / {item.products.unit}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                      disabled={updating === item.id}
                      className="p-1 rounded-md bg-gray-200 hover:bg-gray-300 transition disabled:opacity-50"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center font-semibold">{item.quantity}</span>
                    <button
                      onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                      disabled={updating === item.id || item.quantity >= item.products.stock}
                      className="p-1 rounded-md bg-gray-200 hover:bg-gray-300 transition disabled:opacity-50"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-900">
                      ₹{(item.products.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                  <button
                    onClick={() => handleRemove(item.id)}
                    disabled={updating === item.id}
                    className="text-red-500 hover:text-red-700 transition disabled:opacity-50"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              )) : guestCartItems.map((item) => (
                <div
                  key={item.product.id}
                  className="flex items-center space-x-4 bg-gray-50 rounded-lg p-4"
                >
                  <img
                    src={item.product.image_url}
                    alt={item.product.name}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate">
                      {item.product.name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      ₹{item.product.price} / {item.product.unit}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => updateGuestQuantity(item.product.id, item.quantity - 1)}
                      disabled={updating === item.product.id}
                      className="p-1 rounded-md bg-gray-200 hover:bg-gray-300 transition disabled:opacity-50"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center font-semibold">{item.quantity}</span>
                    <button
                      onClick={() => updateGuestQuantity(item.product.id, item.quantity + 1)}
                      disabled={updating === item.product.id || item.quantity >= item.product.stock}
                      className="p-1 rounded-md bg-gray-200 hover:bg-gray-300 transition disabled:opacity-50"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-900">
                      ₹{(item.product.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                  <button
                    onClick={() => handleRemove(item.product.id)}
                    disabled={updating === item.product.id}
                    className="text-red-500 hover:text-red-700 transition disabled:opacity-50"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {hasItems && (
          <div className="border-t p-6 bg-gray-50">
            <div className="flex items-center justify-between mb-4">
              <span className="text-lg font-semibold text-gray-900">Total</span>
              <span className="text-2xl font-bold text-gray-900">₹{cartTotal.toFixed(2)}</span>
            </div>
            <button
              onClick={onCheckout}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-3 rounded-lg font-semibold hover:from-orange-700 hover:to-red-700 transition"
            >
              Proceed to Checkout
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
